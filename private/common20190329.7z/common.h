#ifndef myCommon_h
#define myCommon_h

#include <arduino.h>
#include <TimeLib.h>
#include <ArduinoJson.h>
#include <FS.h>

#include <NoFUSSClient.h>

#include <WiFiManager.h>    //https://github.com/tzapu/WiFiManager

// needed for justwifi
#include <JustWifi.h>
#include <JustWifiUtils.h>
#include <ESP8266WiFi.h>
#include <ESP8266mDNS.h>

#include <onebutton.h>
#define BUTTON1             D3  //GPIO 0

#define APP_NAME            "Anemometer"
#define APP_VERSION         "1.0.3" // Updated 2018-06-05 10:00 compiled 21/01/19
#define APP_AUTHOR          "dimitris19@gmail.com"
#define APP_WEBSITE         "http://studio19.gr"

#define LED_PIN             D0 // D0 = OnBoard led (LOW = led ON) Do not use sleep mode if use this pin as LED

typedef struct {
    // general
    char ssid[31];
    char password[63];
    char mqttBroker[60];
    uint16_t mqttPort;
    char mqttUser[20];
    char mqttPass[63];
    char mqttTopic[60];                 // I use 3 topics /data /stat /cmd
    uint16_t mqttTopicDataInterval;
    uint16_t mqttTopicStatusInterval;
    char firmwareUpdateServer[80];
    uint16_t firmwareUpdateInterval;
} appSettings_t;

appSettings_t appSettings = {"ssid",                // wifi to connect
                             "password",            // wifi password
                             "139.91.162.159",   // mqtt broker
                             11883,                  // mqtt port
                             "olon",                // mqtt user
                             "oP900Miz",            // mqtt password
                             "anemo/01/",           // mqtt topic
                             120,                   // data topic update interval
                             600,                   // status topic update interval
                             "http://studio19.gr/esp8266/anemometer/firmware/", // firmware url
                             900};                  // firmware update interval

#define CONFIGFILE "/config.json"

#define ENABLE_DEBUG_PRINT 1
#define SEND_DATA 1

#ifdef ENABLE_DEBUG_PRINT
  #define DEBUG_PRINT(...) Serial.printf(__VA_ARGS__)
  #define DEBUG_PRINT_F(...) Serial.printf_P(__VA_ARGS__)
#else
  #define DEBUG_PRINT(...)
  #define DEBUG_PRINT_F(...)
#endif

#include <EEPROM.h>
#define EEPROM_SIZE             4096            // EEPROM size in bytes
#define SPI_FLASH_SEC_SIZE      4096

#define MQTT_ENABLED 1

#ifdef MQTT_ENABLED
    #include <PubSubClient.h>
    const char _statusPayload[] PROGMEM =
        "{\"devi\":\"%s\","
        "\"vers\":\"%s\","      
        "\"ssid\":\"%s\","
        "\"pass\":\"%s\","
        "\"bssi\":\"%s\","
        "\"rssi\":\"%s\","
        "\"time\":\"%s\","
        "\"uptm\":\"%s\","
        "\"memo\":\"%s\","
        "\"rstr\":\"%s\","
        "\"mbro\":\"%s\","
        "\"mprt\":\"%d\","
        "\"musr\":\"%s\","
        "\"mpsw\":\"%s\""
        "}";
    
    bool mqttConnected = false;
    WiFiClient wifiClient;
    PubSubClient mqttClient(wifiClient);
    
    const char _topicData[]    PROGMEM = {"data"};
    const char _topicStatus[]  PROGMEM = {"stat"};
    const char _topicCommand[] PROGMEM = {"cmd"};    

#endif

String statusString = "Starting";

#define OLED1306 

#ifdef OLED1306
    #include <Wire.h>           // Only needed for Arduino 1.6.5 and earlier
    #include "SSD1306Wire.h"    // legacy include: `#include "SSD1306.h"`
    // #include <brzo_i2c.h> // Only needed for Arduino 1.6.5 and earlier
    // #include "SSD1306Brzo.h"
    // #include "SH1106Brzo.h"
    // Include the UI lib
    //#include "OLEDDisplayUi.h"
    // Initialize the OLED display using Wire library
    SSD1306Wire  display(0x3c, D2, D1);
    // SH1106 display(0x3c, D3, D5);

    //OLEDDisplayUi ui ( &display );
    int screenW = 128;
    int screenH = 64;        // top yellow part is 16 px height
    bool screenOn = true;
    uint32_t lastTimeScreenOn = 0;
    uint32_t screenSaverTime = 120;  // seconds
#endif 

// ============================== time library ================================

#include <NTPClient.h>      // https://github.com/arduino-libraries/NTPClient
#include <TimeLib.h>        // https://github.com/PaulStoffregen/Time
#include <WiFiUdp.h>        // needed for ntp time
const int timeZone = 7200;  // in secs. 7200=2hours. Central European Time (UTC = 0)

WiFiUDP ntpUDP;
#define CLOCK_SYNC_INTERVAL 3600 // update clock every X seconds
// You can specify the time server pool and the offset (in seconds, can be
// changed later with setTimeOffset() ). Additionaly you can specify the
// update interval (in milliseconds, can be changed using setfirmwareUpdateInterval() ).
NTPClient timeClient(ntpUDP, "europe.pool.ntp.org", timeZone, CLOCK_SYNC_INTERVAL * 1000);

#include <Timezone.h>       //https://github.com/JChristensen/Timezone
TimeChangeRule myDST = {"EDT", Last, Sun, Mar, 3, 60};  // summer time
TimeChangeRule mySTD = {"EST", Last, Sun, Oct, 4, 0};   // Standard time
Timezone myTime(myDST, mySTD);
// access the time by: localTime = myTime.toLocal(now());

// ============================================================================

// ================== onebutton =====================
OneButton button1(BUTTON1, true);
uint32_t longPressStart = 0;
//===================================================


//=============================================================================

unsigned int sectors(size_t size) {
    return (int) (size + SPI_FLASH_SEC_SIZE - 1) / SPI_FLASH_SEC_SIZE;
}

size_t settingsMaxSize() {
    size_t size = EEPROM_SIZE;
    if (size > SPI_FLASH_SEC_SIZE) size = SPI_FLASH_SEC_SIZE;
    size = (size + 3) & (~3);
    return size;
}

bool spiffsExist = true;

void info() {

    DEBUG_PRINT_F(PSTR("\n\n"));
    DEBUG_PRINT_F(PSTR("[INIT] %s %s\n"), (char *) APP_NAME, (char *) APP_VERSION);
    DEBUG_PRINT_F(PSTR("[INIT] %s\n"), (char *) APP_AUTHOR);
    DEBUG_PRINT_F(PSTR("[INIT] %s\n\n"), (char *) APP_WEBSITE);
    DEBUG_PRINT_F(PSTR("[INIT] CPU chip ID: 0x%06X\n"), ESP.getChipId());
    DEBUG_PRINT_F(PSTR("[INIT] CPU frequency: %u MHz\n"), ESP.getCpuFreqMHz());
    DEBUG_PRINT_F(PSTR("[INIT] SDK version: %s\n"), ESP.getSdkVersion());
    DEBUG_PRINT_F(PSTR("[INIT] Core version: %s\n"), ESP.getCoreVersion().c_str());
    DEBUG_PRINT_F(PSTR("\n"));

    FlashMode_t mode = ESP.getFlashChipMode();
    DEBUG_PRINT_F(PSTR("[INIT] Flash chip ID: 0x%06X\n"), ESP.getFlashChipId());
    DEBUG_PRINT_F(PSTR("[INIT] Flash speed: %u Hz\n"), ESP.getFlashChipSpeed());
    DEBUG_PRINT_F(PSTR("[INIT] Flash mode: %s\n"), mode == FM_QIO ? "QIO" : mode == FM_QOUT ? "QOUT" : mode == FM_DIO ? "DIO" : mode == FM_DOUT ? "DOUT" : "UNKNOWN");
    DEBUG_PRINT_F(PSTR("\n"));
    DEBUG_PRINT_F(PSTR("[INIT] Flash sector size: %8u bytes\n"), SPI_FLASH_SEC_SIZE);
    DEBUG_PRINT_F(PSTR("[INIT] Flash size (CHIP): %8u bytes\n"), ESP.getFlashChipRealSize());
    DEBUG_PRINT_F(PSTR("[INIT] Flash size (SDK):  %8u bytes / %4d sectors\n"), ESP.getFlashChipSize(), sectors(ESP.getFlashChipSize()));
    DEBUG_PRINT_F(PSTR("[INIT] Firmware size:     %8u bytes / %4d sectors\n"), ESP.getSketchSize(), sectors(ESP.getSketchSize()));
    DEBUG_PRINT_F(PSTR("[INIT] OTA size:          %8u bytes / %4d sectors\n"), ESP.getFreeSketchSpace(), sectors(ESP.getFreeSketchSpace()));
    DEBUG_PRINT_F(PSTR("\n"));    
    DEBUG_PRINT_F(PSTR("[INIT] EEPROM size:       %8u bytes / %4d sectors\n"), settingsMaxSize(), sectors(settingsMaxSize()));
    DEBUG_PRINT_F(PSTR("[INIT] Empty space:       %8u bytes /    4 sectors\n"), 4 * SPI_FLASH_SEC_SIZE);
    DEBUG_PRINT_F(PSTR("\n"));    
    FSInfo fs_info;
    bool fs = SPIFFS.info(fs_info);
    if (fs) {        
        DEBUG_PRINT_F(PSTR("[INIT] SPIFFS size:       %8u bytes / %4d sectors\n"), fs_info.totalBytes, sectors(fs_info.totalBytes));
        DEBUG_PRINT_F(PSTR("[INIT] SPIFFS total size: %8u bytes\n"), fs_info.totalBytes);
        DEBUG_PRINT_F(PSTR("[INIT]        used size:  %8u bytes\n"), fs_info.usedBytes);
        DEBUG_PRINT_F(PSTR("[INIT]        block size: %8u bytes\n"), fs_info.blockSize);
        DEBUG_PRINT_F(PSTR("[INIT]        page size:  %8u bytes\n"), fs_info.pageSize);
        DEBUG_PRINT_F(PSTR("[INIT]        max files:  %8u\n"), fs_info.maxOpenFiles);
        DEBUG_PRINT_F(PSTR("[INIT]        max length: %8u\n"), fs_info.maxPathLength);
    } else {
        DEBUG_PRINT_F(PSTR("[INIT] No SPIFFS partition\n"));

    }
    DEBUG_PRINT_F(PSTR("\n"));

}

String TwoDigitNumber(int n)
{
    if (n >= 0 && n < 10)
        return '0' + String(n);
    else
        return String(n);
}

time_t getLocalTime() {
    return myTime.toLocal(now());
}

String URLEncode2(const char *msg)
{
    const char *hex = "0123456789abcdef";
    String encodedMsg = "";

    while (*msg != '\0')
    {
        if (('a' <= *msg && *msg <= 'z') || ('A' <= *msg && *msg <= 'Z') || ('0' <= *msg && *msg <= '9'))
        {
            encodedMsg += *msg;
        }
        else
        {
            encodedMsg += '%';
            encodedMsg += hex[*msg >> 4];
            encodedMsg += hex[*msg & 15];
        }
        msg++;
    }
    return encodedMsg;
}

String Value2String(int y)
{
    return !isnan(y) ? String(y) : "";
}

String Value2String(float y)
{
    return !isnan(y) ? String(y) : "";
}

#define UPTIME_OVERFLOW       4294967295  // Uptime overflow value
unsigned long getUptime() {

    static unsigned long last_uptime = 0;
    static unsigned char uptime_overflows = 0;

    if (millis() < last_uptime) ++uptime_overflows;
    last_uptime = millis();
    unsigned long uptime_seconds = uptime_overflows * (UPTIME_OVERFLOW / 1000) + (last_uptime / 1000);

    return uptime_seconds;
}

// needs timelib.h
String getUpTimeString() {
  uint32_t secs = getUptime();
  char buffer[13];
  snprintf_P(buffer, sizeof(buffer), PSTR("%dT%02d:%02d:%02d"), 
        elapsedDays(secs),
        numberOfHours(secs),
        numberOfMinutes(secs),
        numberOfSeconds(secs) );
  return buffer;
}

String timeToString(time_t time) {
    tmElements_t tm;
    breakTime(time, tm);
    char TimeString[9]; //8 digits plus the null char
    snprintf_P(TimeString, sizeof(TimeString), PSTR("%02d:%02d:%02d"),
        tm.Hour, tm.Minute, tm.Second);
    return TimeString;
}

void debugConfig() {
    DEBUG_PRINT_F(PSTR("\n[CONFIG] ssid: '%s'\n\t pass: '%s'\n\tBroker: %s\n\tPort: %d\n\tUser: %s\n\tPass: %s\n\tTopic: %s\n\tmqttInterval: %d\n\tstatusInterval: %d\n\tOTA server: %s\n\tOTA interval: %d\n"),
    appSettings.ssid, 
    appSettings.password,
    appSettings.mqttBroker,
    appSettings.mqttPort,
    appSettings.mqttUser,
    appSettings.mqttPass,
    appSettings.mqttTopic,
    appSettings.mqttTopicDataInterval,
    appSettings.mqttTopicStatusInterval,
    appSettings.firmwareUpdateServer,
    appSettings.firmwareUpdateInterval);
}

// ================================== spiffs ==================================

void checkFileSystem() {
    spiffsExist = true;
    if (!SPIFFS.begin()) {
        DEBUG_PRINT_F(PSTR("[SPIFFS] File system not exist. Formatting...\n"));
        if (SPIFFS.format()) {
            spiffsExist = true;
            DEBUG_PRINT_F(PSTR("[SPIFFS] File system formatted !!!\n")); 
        } else {
             DEBUG_PRINT_F(PSTR("[SPIFFS] Error formating file system.\n")); 
             spiffsExist = false;
        }
    }
}

bool loadConfig()
{  
    DEBUG_PRINT_F(PSTR("[SPIFFS] Loading config...\n"));
    if (!spiffsExist) return false;
    
    File configFile = SPIFFS.open(CONFIGFILE, "r");
    if (!configFile)
    {
        DEBUG_PRINT_F(PSTR("[SPIFFS] Failed to open config file.\n"));
        return false;
    }

    size_t size = configFile.size();
    if (size > 1024)
    {
        DEBUG_PRINT_F(PSTR("[SPIFFS] Config file size is too large.\n"));
        return false;
    }

    // Allocate a buffer to store contents of the file.
    std::unique_ptr<char[]> buf(new char[size]);

    // We don't use String here because ArduinoJson library requires the input
    // buffer to be mutable. If you don't use ArduinoJson, you may as well
    // use configFile.readString instead.
    configFile.readBytes(buf.get(), size);
    

    DynamicJsonBuffer jsonBuffer;
    JsonObject &json = jsonBuffer.parseObject(buf.get());

    if (!json.success())
    {
        DEBUG_PRINT_F(PSTR("[SPIFFS] Failed to parse config file.\n"));
        return false;
    }
    json.prettyPrintTo(Serial);

    // @todo check if values are null before copying
    strlcpy(appSettings.ssid, json[F("ssid")] | appSettings.ssid, sizeof(appSettings.ssid));    
    strlcpy(appSettings.password, json[F("pass")] | appSettings.password, sizeof(appSettings.password));
    strlcpy(appSettings.mqttBroker, json[F("mbro")] | appSettings.mqttBroker, sizeof(appSettings.mqttBroker));
    appSettings.mqttPort  = json[F("mpor")] | appSettings.mqttPort;
    strlcpy(appSettings.mqttUser, json[F("musr")] | appSettings.mqttUser, sizeof(appSettings.mqttUser));
    strlcpy(appSettings.mqttPass, json[F("mpsw")] | appSettings.mqttPass, sizeof(appSettings.mqttPass));
    strlcpy(appSettings.mqttTopic, json[F("mtop")] | appSettings.mqttTopic, sizeof(appSettings.mqttTopic));
    appSettings.mqttTopicDataInterval = json[F("mdin")] | appSettings.mqttTopicDataInterval;
    appSettings.mqttTopicStatusInterval = json[F("msin")] | appSettings.mqttTopicStatusInterval;
    strlcpy(appSettings.firmwareUpdateServer, json[F("usrv")] | appSettings.firmwareUpdateServer, sizeof(appSettings.firmwareUpdateServer));
    appSettings.firmwareUpdateInterval = json[F("uint")] | appSettings.firmwareUpdateInterval;
    debugConfig();
    return true;
}

bool saveConfig() {

    if (!spiffsExist) return false;
    
    DynamicJsonBuffer jsonBuffer;
    JsonObject& json = jsonBuffer.createObject();

    json[F("ssid")] = appSettings.ssid;
    json[F("pass")] = appSettings.password;
    json[F("mbro")] = appSettings.mqttBroker;
    json[F("mpor")] = appSettings.mqttPort;
    json[F("musr")] = appSettings.mqttUser;
    json[F("mpsw")] = appSettings.mqttPass;
    json[F("mtop")] = appSettings.mqttTopic;
    json[F("mdin")] = appSettings.mqttTopicDataInterval;
    json[F("msin")] = appSettings.mqttTopicStatusInterval;
    json[F("usrv")] = appSettings.firmwareUpdateServer;
    json[F("uint")] = appSettings.firmwareUpdateInterval;

    json.prettyPrintTo(Serial);

    File configFile = SPIFFS.open(CONFIGFILE, "w");
        
    if (!configFile) {
        DEBUG_PRINT_F(PSTR("[SPIFFS] Failed to open config file for writing.\n"));
        return false;
    }
    
    debugConfig();    

    if (json.printTo(configFile) > 0 ) {
        DEBUG_PRINT_F(PSTR("[SPIFFS] Configuration saved to File System.\n"));
        return true;
    }
    else {
        DEBUG_PRINT_F(PSTR("[SPIFFS] Error saving configuration to File System.\n"));
        return false;
    }

}

bool deleteConfig() {
    if (!spiffsExist) return false;
    DEBUG_PRINT_F(PSTR("[SPIFFS] Deleting config file.\n"));
    if (SPIFFS.remove(CONFIGFILE)) {
        DEBUG_PRINT_F(PSTR("[SPIFFS] Config File deleted.\n"));
        return true;
    } else
    { 
        DEBUG_PRINT_F(PSTR("[SPIFFS] Can not delete Config File.\n"));
        return false;
    }
}

    /*  todo: have to check those functions
// https://github.com/G6EJD/Using-ESP8266-EEPROM/blob/master/ESP8266_Reading_and_Writing_EEPROM.ino/
// https://arduino.stackexchange.com/questions/25945/how-to-read-and-write-eeprom-in-esp8266

// Loads string from EEPROM. Returns length of string read.
int loadFlashString(uint16_t startAt, char* buffer, size_t maxLen)
{
    EEPROM.begin(EEPROM_SIZE);
    uint16_t i = 0;
    {
        buffer[i] = (char)EEPROM.read(startAt + i);
        Serial.println(buffer[i]);
    } while(i < maxLen && buffer[i++] != 0);
    Serial.println(buffer);
    EEPROM.end();
    if (i >= maxLen) {
        return -1;
    }
    return i;
}

// Saves string to EEPROM. Returns index position after end of string.
int saveFlashString(uint16_t startAt, const String& id)
{
    uint16_t len = id.length();
    if (len == 0) return -1;
    EEPROM.begin(EEPROM_SIZE);
    for (uint16_t i = 0; i <= len; i++)
    {
        EEPROM.write(i + startAt, (uint8_t) id.c_str()[i]);
    }
    EEPROM.write(startAt + len, 0);
    EEPROM.commit();
    EEPROM.end();
    return startAt + len;
}

int saveFlashWiFi(const String& ssid, const String& pass) {
    uint16_t lenSSID = ssid.length();
    uint16_t lenPass = pass.length();
    if (lenSSID > 31 || lenPass > 63) return -1;       // invalid ssid or password
    EEPROM.begin(EEPROM_SIZE);
    
    // ssid starts at 0. Max is 31 + #0 (31 is the max because 0 is first)  
    uint16_t i;  
    for (i = 0; i <= lenSSID; i++)
    {
        EEPROM.write(i, (uint8_t) ssid.c_str()[i]);
        Serial.println(ssid.c_str()[i]);
    }
    EEPROM.write(lenSSID, 0);
    
    // pass starts at 32
    uint16_t j;
    for (j = 0; j<=lenPass; j++) {
        EEPROM.write(32+j, (uint8_t) pass.c_str()[j]);
        Serial.println(ssid.c_str()[j]);
    }
    EEPROM.write(32+lenPass, 0);
    
    EEPROM.commit();
    EEPROM.end();
    return (i+j);
}

*/
// nofuss section
void nofussSetup() {

    NoFUSSClient.setServer(appSettings.firmwareUpdateServer);
    NoFUSSClient.setDevice(APP_NAME);
    NoFUSSClient.setVersion(APP_VERSION);

    NoFUSSClient.onMessage([](nofuss_t code) {

        if (code == NOFUSS_START) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] Start\n"));
        }

        if (code == NOFUSS_UPTODATE) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] Nothing for me\n"));
        }

        if (code == NOFUSS_PARSE_ERROR) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] Error parsing server response\n"));
        }

        if (code == NOFUSS_UPDATING) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] Updating\n"));
            DEBUG_PRINT_F(PSTR("         New version: %s\n"), NoFUSSClient.getNewVersion().c_str());
            DEBUG_PRINT_F(PSTR("         Firmware: %s\n"), NoFUSSClient.getNewFirmware().c_str());
            DEBUG_PRINT_F(PSTR("         File System: %s\n"), NoFUSSClient.getNewFileSystem().c_str());
        }

        if (code == NOFUSS_FILESYSTEM_UPDATE_ERROR) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] File System Update Error: %s\n"), NoFUSSClient.getErrorString().c_str());
        }

        if (code == NOFUSS_FILESYSTEM_UPDATED) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] File System Updated\n"));
        }

        if (code == NOFUSS_FIRMWARE_UPDATE_ERROR) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] Firmware Update Error: %s\n"), NoFUSSClient.getErrorString().c_str());
        }

        if (code == NOFUSS_FIRMWARE_UPDATED) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] Firmware Updated\n"));
        }

        if (code == NOFUSS_RESET) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] Resetting board\n"));
        }

        if (code == NOFUSS_END) {
            DEBUG_PRINT_F(PSTR("[NoFUSS] End\n"));
        }

    });
}

void nofussLoop() {
    static unsigned long last_check = 0;
    if (WiFi.status() != WL_CONNECTED) return;
    if ((last_check > 0) && ((millis() - last_check) < appSettings.firmwareUpdateInterval*1000)) return;
    last_check = millis();
    NoFUSSClient.handle();
}

// =============================== just wifi start =============================

void jwSetup(){
    
    jw.setHostname(APP_NAME);   // Set WIFI hostname (otherwise it would be ESP_XXXXXX)   

    // Callbacks
    jw.subscribe(infoCallback);
    jw.subscribe(mdnsCallback);
    // AP mode only as fallback
    jw.enableAP(false);
    jw.enableAPFallback(false);

    // Enable STA mode (connecting to a router)
    jw.enableSTA(true);

    // Configure it to scan available networks and connect in order of dBm
    jw.enableScan(true);

    // Clean existing network configuration
    jw.cleanNetworks();

    WiFi.printDiag(Serial);

    // Add saved network
    jw.addCurrentNetwork(false);
    jw.addNetwork("ikaros2", "ikaros2018");
    jw.addNetwork("Studio 19", "oP900Miz");
    jw.addNetwork("VONETS_1CBFF4","12345678");
    // Add an open network
    //jw.addNetwork("forth public access");
    jw.addNetwork("open");

}

// ============================================================================

void restartESP() {
    SPIFFS.end(); // unmount file system before restart
    delay(1000);
    //ESP.reset();    // is a hard reset and can leave some of the registers in the old state which can lead to problems, its more or less like the reset button on the PC.
    ESP.restart();  // tells the SDK to reboot, so its a more clean reboot, use this one if possible.
    delay(5000);
}

void resetESP() {
    DEBUG_PRINT_F(PSTR("[RESET] Reset to factory defaults.\n"));
    deleteConfig();
    delay(1000);
    restartESP();
}

// ----- button 1 callback functions

// This function will be called when the button1 was pressed 1 time
void click1() {
    //Serial.println("Button 1 click.");
    #ifdef OLED1306
        screenOn = true;
        lastTimeScreenOn = millis();
        display.displayOn();
    #endif
} // click1


// This function will be called when the button1 was pressed 2 times in a short timeframe.
void doubleclick1() {
    //Serial.println("Button 1 doubleclick.");
} // doubleclick1


// This function will be called once, when the button1 is pressed for a long time.
void longPressStart1() {
    //Serial.println("Button 1 longPress start");
    longPressStart = millis();
} // longPressStart1


// This function will be called often, while the button1 is pressed for a long time.
void longPress1() {
    //Serial.println("Button 1 longPress...");
} // longPress1


// This function will be called once, when the button1 is released after beeing pressed for a long time.
void longPressStop1() {
    Serial.println("Button 1 longPress stop");
    if (millis() - longPressStart > 5000) {
        resetESP();
    }
} // longPressStop1

// ===================== setupOneButton =============
void oneButtonSetup() {
    // link the button 1 functions.
    button1.attachClick(click1);
    button1.attachDoubleClick(doubleclick1);
    button1.attachLongPressStart(longPressStart1);
    button1.attachLongPressStop(longPressStop1);
    button1.attachDuringLongPress(longPress1);
}

#ifdef OLED1306 

void initSSD1306() {
    display.init();
    display.flipScreenVertically();
    display.setContrast(255);
}

// converts the dBm to a range between 0 and 100%
int8_t getWifiQuality() {
    int32_t dbm = WiFi.RSSI();
    if(dbm <= -100) {
        return 0;
    } else if(dbm >= -50) {
        return 100;
    } else {
        return 2 * (dbm + 100);
    }
}
  
void _drawWifiQuality(int8_t quality) {    
    display.setColor(BLACK);
    display.fillRect(90, 0, 38, 12);
    display.setColor(WHITE);
    display.setTextAlignment(TEXT_ALIGN_RIGHT);  
    display.setFont(ArialMT_Plain_10);
    if (WiFi.isConnected()) {
        display.drawString(118, 0, String(quality) + "%");
        for (int8_t i = 0; i < 4; i++) {
            for (int8_t j = 0; j < 2 * (i + 1); j++) {
                if (quality > i * 25 || j == 0) {
                    display.setPixel(120 + 2 * i, 9 - j);
                }
            }
        }
    } else {
        display.drawString(118, 0, F("-----"));
    }
        
}

void _oledUpdateStatusText() {
    display.setColor(BLACK);
    display.fillRect(0,0, 89,12);
    display.setColor(WHITE);
    display.setTextAlignment(TEXT_ALIGN_LEFT);
    if (statusString == "") {
        statusString = WiFi.localIP().toString();
    }
    display.drawString(0,0, statusString);
    static unsigned long last_check = 0;    
    if ((last_check > 0) && ((millis() - last_check) < 3000)) return;
    last_check = millis();
    statusString = "";
    
}

void _oledLoop() {
    static unsigned long last_check = 0;    
    if ((last_check > 0) && ((millis() - last_check) < 1000)) return;
    last_check = millis();
    if (screenOn) {
        _drawWifiQuality(getWifiQuality());
        _oledUpdateStatusText();
        display.display();
    }
}

#endif

// =============================== MQTT ===============================

#ifdef MQTT_ENABLED

void _statusReport(); // used later
bool _mqttSendMessage(const char * message);

void _mqttOnMessage(char* topic, char* payload, unsigned int len) {

    if (len == 0) return;

    char message[len + 1];
    strlcpy(message, (char *) payload, len + 1);
    message[len] = '\0';
    DEBUG_PRINT_F(PSTR("[MQTT] Topic: %s \tMessage: %s\n"), topic, message);
    
    char* command = strtok(message," ");
    
    if (strcmp("status", command) == 0) {
        //send status report
        _statusReport();
    };
    
    if (strcmp("reset", command) == 0) {
        _mqttSendMessage("Reseting...");
        delay(2000);
        resetESP();
        delay(5000);
    }
    
    if (strcmp("restart", command) == 0) {
        _mqttSendMessage("Restarting...");
        delay(2000);
        ESP.restart();
        delay(5000);        
    }
    
    if (strcmp("update", command) == 0) {
        _mqttSendMessage("Updating...");
        NoFUSSClient.handle();        
    }

    if (strcmp("broker", command) == 0) {   // command is: broker user:password@domain_or_ip:port
        char* userid = strtok(NULL,":");
        char* password = strtok(NULL, "@");
        char* url = strtok(NULL,":");
        char* port = strtok(NULL, "");
        
        if (userid != NULL)  {              
            if (strcmp("*", userid) > 0) {  // if user or password is blank, use * 
                appSettings.mqttUser[0] = 0;   
            } else {
                strcpy(appSettings.mqttUser, userid);
            }
        }

        if (password != NULL) {
            if (strcmp("*", password) > 0) {
                appSettings.mqttPass[0] = 0;
            } else {
                strcpy(appSettings.mqttPass, password);
            }
        }
        if (url != NULL) {
            strcpy(appSettings.mqttBroker, url);
        }
        if (port != NULL) {
            appSettings.mqttPort = atoi(port);
        }
        debugConfig();
        _mqttSendMessage("Saving new broker.");
        saveConfig();        
    }

    if (strcmp("interval", command) == 0) {
        char* value = strtok(NULL,"");
        if (value != NULL) {
            appSettings.mqttTopicDataInterval = atoi(value);
            _mqttSendMessage("Saving new interval.");
            saveConfig();
        }
    }

}


void mqttCallback(char* topic, byte* payload, unsigned int length) {
    // handle message arrived
    _mqttOnMessage(topic, (char *) payload, length);
}

bool mqttConnect() {
    if (WiFi.status() != WL_CONNECTED) {
        DEBUG_PRINT_F(PSTR("[MQTT] No WiFi connection \n"));        
        return (mqttConnected = false);
    }
    DEBUG_PRINT_F(PSTR("[MQTT] Connecting to MQTT... \n"));
    mqttConnected = mqttClient.connected();
    if (!mqttConnected) {
        DEBUG_PRINT_F(PSTR("[MQTT] connecting to: \n\t%s\n\tPort: %d\n\tUser: %s\n\tpass: %s\n"),
                appSettings.mqttBroker,appSettings.mqttPort,
                appSettings.mqttUser, appSettings.mqttPass );
        mqttClient.setServer(appSettings.mqttBroker, appSettings.mqttPort);
        mqttClient.setCallback(mqttCallback);
        String clientId = (char *) APP_NAME;
        clientId += "-" + WiFi.macAddress();        
        if ( mqttClient.connect(clientId.c_str(), appSettings.mqttUser, appSettings.mqttPass) ) {
            DEBUG_PRINT_F(PSTR("[MQTT] Connected.\n"));
            String topic;
            topic = String(appSettings.mqttTopic) + FPSTR(_topicCommand); 
            mqttClient.subscribe(topic.c_str());
            mqttConnected = true;
        } else {
            DEBUG_PRINT_F(PSTR("[MQTT] Connection failed] rc = %d\n"), mqttClient.state());            
        }
    } else {
        DEBUG_PRINT_F(PSTR("[MQTT] Already connected.\n"));
    }
    return mqttConnected;
}

bool _mqttSendMessage(const char * message){
    bool result = false;
    if (mqttConnect()) {
        statusString = "Sending...";
        String topic;
        topic = String(appSettings.mqttTopic) + FPSTR(_topicStatus);
        DEBUG_PRINT(topic.c_str());
        result = (mqttClient.publish(topic.c_str(), message) == true);
    }
    if (result) {
        DEBUG_PRINT_F(PSTR("[MQTT] Success sending message.\n"));
    } else {
        DEBUG_PRINT_F(PSTR("[MQTT] Error sending message.\n"));
    }
    return result;
}

void _statusReport() {
    char buffer[400] = {};
    snprintf_P(buffer, sizeof(buffer),
        _statusPayload,
        (char *) APP_NAME,
        (char *) APP_VERSION,
        WiFi.SSID().c_str(),
        WiFi.psk().c_str(),
        WiFi.BSSIDstr().c_str(),
        String(WiFi.RSSI()).c_str(),
        timeToString(getLocalTime()).c_str(),
        getUpTimeString().c_str(),
        String(ESP.getFreeHeap()).c_str(),
        String(ESP.getResetReason()).c_str(),
        String(appSettings.mqttBroker).c_str(),
        appSettings.mqttPort,
        String(appSettings.mqttUser).c_str(),
        String(appSettings.mqttPass).c_str()
        );
    
    DEBUG_PRINT("\n[MQTT BUFFER] %s\n", buffer);

    _mqttSendMessage(buffer);

}

void _statusReportLoop() {
    static uint32_t last_check = 0;
    if (WiFi.status() != WL_CONNECTED) return;
    if (appSettings.mqttTopicStatusInterval == 0) return;
    if ((last_check > 0) && ((millis() - last_check) < (appSettings.mqttTopicStatusInterval*1000))) return;
    last_check = millis();
    _statusReport();
}

void _mqttLoop() {
    if (WiFi.status() != WL_CONNECTED) 
        return;

    if (!mqttClient.connected()) {
        static uint32_t last_check = 0;
        if ((last_check == 0) || (millis() - last_check) > 10000) {    
            last_check = millis();
            DEBUG_PRINT_F(PSTR("[MQTT] (mqttloop) Not connected. Reconnecting.\n"));
            mqttConnect();
        }
    } else {
        mqttClient.loop();

        _statusReportLoop();

    }
}

#endif

void initialize(){
    Serial.begin(115200);
    Serial.setDebugOutput(true);

    // check file system
    DEBUG_PRINT_F("[DEBUG] Checking file system.\n");
    checkFileSystem();
    DEBUG_PRINT_F("[DEBUG] Print default configuration.\n");
    debugConfig();

    // loading configuration
    loadConfig();


    #ifdef OLED1306
        initSSD1306();
    #endif

    DEBUG_PRINT_F("[DEBUG] Printing info.\n");
    info();

    DEBUG_PRINT_F("[DEBUG] Setup oneButton.\n");
    oneButtonSetup();

    // setup wifi
    DEBUG_PRINT_F("[DEBUG] Setup wifi.\n");
    jwSetup();

    // setup OTA updates
    DEBUG_PRINT_F("[DEBUG] Setup FOTA updater.\n");
    nofussSetup();    

    // start time client
    DEBUG_PRINT_F("[DEBUG] Starting ntp client.\n");
    timeClient.begin();
}


void startWiFiManager() {
    DEBUG_PRINT_F("Starting wifi manager.\n");
    char buf[6];
    buf[0] = 0;
    WiFiManagerParameter custom_mqtt_broker("server", "mqtt server", appSettings.mqttBroker, 60);
    WiFiManagerParameter custom_mqtt_port("port", "mqtt port", itoa(appSettings.mqttPort, buf, 10), 6);
    WiFiManagerParameter custom_mqtt_user("user", "mqtt user", appSettings.mqttUser, 60);    
    WiFiManagerParameter custom_mqtt_password("password", "mqtt password", appSettings.mqttPass, 60);    
    WiFiManagerParameter custom_mqtt_topic("topic", "mqtt topic", appSettings.mqttTopic, 60);
    buf[0] = '\0';
    WiFiManagerParameter custom_mqtt_update("update", "update in secs", itoa(appSettings.mqttTopicDataInterval, buf, 10), 6);
    WiFiManager wifiManager;
    //wifiManager.resetSettings(); //reset settings - for testing
        //add all your parameters here
    wifiManager.addParameter(&custom_mqtt_broker);
    wifiManager.addParameter(&custom_mqtt_port);
    wifiManager.addParameter(&custom_mqtt_user);
    wifiManager.addParameter(&custom_mqtt_password);
    wifiManager.addParameter(&custom_mqtt_topic);
    wifiManager.addParameter(&custom_mqtt_update);

    wifiManager.setTimeout(120); //(in seconds) sets timeout until configuration portal gets turned off

    //it starts an access point with the specified name
    //here  "AutoConnectAP"
    //and goes into a blocking loop awaiting configuration

    //WITHOUT THIS THE AP DOES NOT SEEM TO WORK PROPERLY WITH SDK 1.5 , update to at least 1.5.1
    //WiFi.mode(WIFI_STA);
    
    if (!wifiManager.startConfigPortal((char *) APP_NAME)) {
        DEBUG_PRINT_F("failed to connect and hit timeout\n");
        restartESP();
    }
    //if you get here you have connected to the WiFi
    DEBUG_PRINT_F("connected...yeey :)\n");
    WiFi.printDiag(Serial);
    //save SSID and password to flash
    strcpy(appSettings.ssid, WiFi.SSID().c_str());
    strcpy(appSettings.password, WiFi.psk().c_str());
    // save mqtt settings to flash
    strcpy(appSettings.mqttBroker, custom_mqtt_broker.getValue());
    appSettings.mqttPort = atoi(custom_mqtt_port.getValue());
    strcpy(appSettings.mqttUser, custom_mqtt_user.getValue());
    strcpy(appSettings.mqttPass, custom_mqtt_password.getValue());
    strcpy(appSettings.mqttTopic, custom_mqtt_topic.getValue());
    appSettings.mqttTopicDataInterval = atoi(custom_mqtt_update.getValue());
    debugConfig();
    saveConfig();   // save configuration and restart esp
    restartESP();    
}

void wifiLoop() {
    if (!captivePortal) {
        jw.loop();
        if (jw.connected()) {

            nofussLoop();  // check for firmware updates

            if (timeClient.update()) {
                setTime(timeClient.getEpochTime()); // update system time with ntp time
            }

        }
    } else {
        startWiFiManager();
    }
}

void appLoop(){
    #ifdef OLED1306
        _oledLoop();
    #endif

    #ifdef MQTT_ENABLED
        _mqttLoop();
    #endif
}

#endif